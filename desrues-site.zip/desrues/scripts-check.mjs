// Bloque la mise en ligne tant qu'il reste des informations à compléter.
import { readFileSync } from 'node:fs'
const src = readFileSync('src/App.tsx', 'utf8')
const todos = [...src.matchAll(/<Todo>([\s\S]*?)<\/Todo>/g)].map((m) => m[1].replace(/\s+/g, ' ').trim())
if (todos.length) {
  console.error(`\n✖ ${todos.length} information(s) légale(s) à compléter avant la mise en ligne :\n`)
  todos.forEach((t, i) => console.error(`  ${i + 1}. ${t}`))
  console.error('')
  process.exit(1)
}
console.log('✔ Aucune information à compléter.')
