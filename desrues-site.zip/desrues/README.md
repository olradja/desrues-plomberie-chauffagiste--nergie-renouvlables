# Site Desrues – Plomberie, chauffage, énergies renouvelables (Saint-Malo)

React + Vite + TypeScript + Tailwind CSS. Tout le site est dans `src/App.tsx`.

## Commandes
- `npm install` puis `npm run dev` : développement local.
- `npm run check` : liste les informations légales encore à compléter.
- `npm run build` : site de production dans `dist/`. **Refuse de construire tant qu'une information légale manque.**
- `npm run build:preview` : maquette en un seul fichier HTML (`dist-preview/index.html`), pour montrer le site au client.

## Mise en ligne (Hostinger)
Envoyer le contenu de `dist/` (y compris `.htaccess`) dans `public_html`. Le `.htaccess` force le HTTPS et ajoute les en-têtes de sécurité.

## Choix de conformité
- Aucun cookie, aucun traceur, aucun outil d'analyse d'audience → pas de bandeau de consentement (art. 82 loi Informatique et Libertés).
- Aucune ressource tierce : police Open Sauce One (licence OFL) et images hébergées avec le site. Pas d'iframe Google Maps (simple lien).
- Formulaire en `mailto:` : le site ne reçoit ni ne stocke aucune donnée.
- CSP stricte dans `index.html`. Si vous ajoutez un service tiers (analytics, carte, formulaire Formspree…), il faut mettre à jour la CSP, la politique de confidentialité, la politique de cookies, et ajouter un bandeau de consentement si le service n'est pas exempté.

## Informations à obtenir du client AVANT mise en ligne
Voir `npm run check`. En résumé : hébergeur, médiateur de la consommation, assurance décennale, n° de certificat RGE, barème (taux horaire TTC, déplacement, devis, forfaits), fournisseur de messagerie. Faire aussi valider par le client : capital social (Kbis), horaires, mention « depuis 1956 », droits sur les photos, et la liste des prestations.
