import { useCallback, useEffect, useRef, useState } from 'react'
import type { CSSProperties, FormEvent, ReactNode, RefObject } from 'react'
import HERO_IMAGE from './assets/camionnette-desrues.webp'
import SIGN_IMAGE from './assets/enseigne-desrues.webp'
import MOTIF_IMAGE from './assets/motif-flammes.svg'

/* ============================================================================
   INFORMATIONS DE L'ENTREPRISE
   Sources : Recherche d'entreprises (data.gouv.fr), societe.com, annuaire RGE.
   Toute information balisée « Todo » doit être complétée AVANT mise en ligne
   (`npm run build` refuse de construire le site tant qu'il en reste).
   ========================================================================== */
const COMPANY = {
  brand: 'Desrues',
  legalName: 'DESRUES - GUINARD ET ASSOCIES',
  legalForm: 'Société par actions simplifiée (SAS)',
  capital: '10 000 €',
  street: '12 rue du Docteur Jean Thiboumery',
  zip: '35400',
  city: 'Saint-Malo',
  phoneDisplay: '02 99 82 03 03',
  phoneHref: 'tel:+33299820303',
  email: 'stmalo@desruesplomberie.fr',
  siren: '423 343 912',
  siret: '423 343 912 00048',
  rcs: 'RCS Saint-Malo 423 343 912',
  vat: 'FR78423343912',
  naf: '43.22A – Travaux d’installation d’eau et de gaz en tous locaux',
  president: 'Benjamin Guinard',
  hours: [
    { days: 'Lundi – vendredi', time: '8 h 30 – 12 h 00 · 13 h 30 – 18 h 00' },
    { days: 'Samedi, dimanche', time: 'Fermé' },
  ],
}
// Fiche Google Maps de l'entreprise (paramètres de suivi retirés de l'URL)
const MAPS_URL =
  'https://www.google.com/maps/place/Desrues+Guinard+plomberie/@48.6225126,-1.9842066,16z/data=!4m6!3m5!1s0x480e83bdd7b3845b:0x58424540d2dfff10!8m2!3d48.622433!4d-1.9786559!16s%2Fg%2F11j1j6yfyp'

/* ============================================================================
   DONNÉES
   ========================================================================== */
const featureBars = ['Plomberie', 'Chauffage', 'Énergies renouvelables']

const services = [
  { name: 'Pompe\nà chaleur', num: '01', active: true },
  { name: 'Chaudière\nà condensation', num: '02', active: false },
  { name: 'Chauffe-eau\nthermo­dynamique', num: '03', active: false },
  { name: 'Plomberie\nsanitaire', num: null, active: false },
]

const NAV_LINKS = [
  { label: 'Accueil', href: '#accueil' },
  { label: 'Nos métiers', href: '#metiers' },
  { label: 'Énergies renouvelables', href: '#renouvelables' },
  { label: 'Tarifs', href: '#tarifs' },
  { label: 'Contact', href: '#contact' },
]

const LEGAL_PAGES = {
  '#/mentions-legales': 'Mentions légales',
  '#/confidentialite': 'Politique de confidentialité',
  '#/cookies': 'Politique de cookies',
  '#/conditions': 'Devis, rétractation et remboursement',
} as const
type LegalRoute = keyof typeof LEGAL_PAGES

/* ============================================================================
   UTILITAIRES
   ========================================================================== */

/** Information manquante : affichée en surbrillance et bloquante au build. */
function Todo({ children }: { children: ReactNode }) {
  return (
    <mark className="bg-yellow-200 text-black px-1 rounded font-semibold">[À compléter : {children}]</mark>
  )
}

function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(
    () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  )
  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)')
    const on = () => setReduced(mq.matches)
    mq.addEventListener('change', on)
    return () => mq.removeEventListener('change', on)
  }, [])
  return reduced
}

function useIsMobile() {
  const [isMobile, setIsMobile] = useState(
    () => typeof window !== 'undefined' && window.matchMedia('(max-width: 767px)').matches,
  )
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 767px)')
    const on = (e: MediaQueryListEvent) => setIsMobile(e.matches)
    mq.addEventListener('change', on)
    return () => mq.removeEventListener('change', on)
  }, [])
  return isMobile
}

type MaskPosition = { x: number; y: number; sw: number; sh: number }

function useMaskPositions(
  sectionRef: RefObject<HTMLElement | null>,
  cardsRef: RefObject<(HTMLElement | null)[]>,
) {
  const [positions, setPositions] = useState<MaskPosition[]>([])
  useEffect(() => {
    const section = sectionRef.current
    if (!section) return
    const measure = () => {
      const s = section.getBoundingClientRect()
      setPositions(
        cardsRef.current.map((card) => {
          if (!card) return { x: 0, y: 0, sw: s.width, sh: s.height }
          const c = card.getBoundingClientRect()
          return { x: c.left - s.left, y: c.top - s.top, sw: s.width, sh: s.height }
        }),
      )
    }
    measure()
    const ro = new ResizeObserver(measure)
    ro.observe(section)
    cardsRef.current.forEach((c) => c && ro.observe(c))
    return () => ro.disconnect()
  }, [sectionRef, cardsRef])
  return positions
}

function useImageWidth(src: string, sectionHeight: number) {
  const [natural, setNatural] = useState<{ w: number; h: number } | null>(null)
  useEffect(() => {
    const img = new Image()
    img.onload = () => setNatural({ w: img.naturalWidth, h: img.naturalHeight })
    img.src = src
  }, [src])
  if (!natural || !sectionHeight) return 0
  return natural.w * (sectionHeight / natural.h)
}

function MaskedCard({
  bgImage,
  position,
  imageWidth,
  focalX,
  className = '',
  children,
  cardRef,
  style,
  as: Tag = 'div',
}: {
  bgImage: string
  position?: MaskPosition
  imageWidth: number
  focalX: number
  className?: string
  children?: ReactNode
  cardRef?: (el: HTMLElement | null) => void
  style?: CSSProperties
  as?: 'div' | 'article'
}) {
  const pos = position ?? { x: 0, y: 0, sw: 0, sh: 0 }
  const overflow = imageWidth > pos.sw ? imageWidth - pos.sw : 0
  const focalOffset = overflow * focalX
  return (
    <Tag
      ref={cardRef as never}
      className={className}
      style={{
        ...style,
        backgroundColor: '#0B5D33',
        backgroundImage: `url("${bgImage}")`,
        backgroundSize: pos.sh ? `auto ${pos.sh}px` : 'cover',
        backgroundPosition: `-${pos.x + focalOffset}px -${pos.y}px`,
        backgroundRepeat: 'no-repeat',
      }}
    >
      {children}
    </Tag>
  )
}

function useStaggeredReveal(count: number, threshold = 0.15) {
  const reduced = usePrefersReducedMotion()
  const [visible, setVisible] = useState(false)
  const containerRef = useRef<HTMLElement | null>(null)
  useEffect(() => {
    const el = containerRef.current
    if (!el || visible) return
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true)
          io.disconnect()
        }
      },
      { threshold },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [threshold, visible])
  const getAnimStyle = (index: number): CSSProperties => {
    if (reduced || index >= count) return {}
    return {
      opacity: visible ? 1 : 0,
      transform: visible ? 'translateY(0)' : 'translateY(24px)',
      transition: `opacity 0.6s cubic-bezier(0.16,1,0.3,1) ${index * 120}ms, transform 0.6s cubic-bezier(0.16,1,0.3,1) ${index * 120}ms`,
    }
  }
  return { containerRef, getAnimStyle }
}

/** Combine plusieurs refs sur un même élément. */
function mergeRefs<T>(...refs: RefObject<T | null>[]) {
  return (el: T | null) => refs.forEach((r) => ((r as { current: T | null }).current = el))
}

function ArrowIcon({ className = '' }: { className?: string }) {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" className={`rotate-[-45deg] ${className}`} aria-hidden="true" focusable="false">
      <path d="M1 7h12m0 0L8 2m5 5L8 12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function NewTabHint() {
  return <span className="sr-only"> (s’ouvre dans un nouvel onglet)</span>
}

/* ============================================================================
   NAVIGATION
   ========================================================================== */
function Logo() {
  return (
    <a href="#accueil" className="flex flex-col text-black" aria-label="Desrues – retour à l’accueil">
      <span className="text-xl md:text-2xl font-extrabold uppercase tracking-tight leading-none">Desrues</span>
      <span className="text-xl md:text-2xl font-extrabold uppercase tracking-tight leading-none -mt-0.5 md:-mt-1 text-[#0B5D33]">Saint-Malo</span>
      <span className="text-[8px] md:text-[9px] font-medium leading-none mt-1.5 md:mt-2">plomberie · chauffage · énergies renouvelables</span>
    </a>
  )
}

function Navbar() {
  const [open, setOpen] = useState(false)
  const toggleRef = useRef<HTMLButtonElement>(null)
  const desktopToggleRef = useRef<HTMLButtonElement>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const lastToggle = useRef<HTMLButtonElement | null>(null)

  const close = useCallback(() => {
    setOpen(false)
    lastToggle.current?.focus()
  }, [])

  useEffect(() => {
    if (!open) return
    document.body.style.overflow = 'hidden'
    const first = panelRef.current?.querySelector<HTMLElement>('a,button')
    first?.focus()
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close()
      if (e.key === 'Tab' && panelRef.current) {
        const items = panelRef.current.querySelectorAll<HTMLElement>('a,button')
        const f = items[0]
        const l = items[items.length - 1]
        if (e.shiftKey && document.activeElement === f) {
          e.preventDefault()
          l.focus()
        } else if (!e.shiftKey && document.activeElement === l) {
          e.preventDefault()
          f.focus()
        }
      }
    }
    document.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      document.removeEventListener('keydown', onKey)
    }
  }, [open, close])

  const openFrom = (btn: HTMLButtonElement | null) => {
    lastToggle.current = btn
    setOpen((o) => !o)
  }

  const linkDelay = (i: number): CSSProperties => ({ transitionDelay: open ? `${100 + i * 60}ms` : '0ms' })

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 md:px-6 py-2 md:py-3 bg-white/90 backdrop-blur-md">
        <Logo />
        <div className="hidden md:flex items-center gap-6">
          <a href={COMPANY.phoneHref} className="text-sm font-semibold text-black underline-offset-4 hover:underline">
            Appeler le {COMPANY.phoneDisplay}
          </a>
          <button
            ref={desktopToggleRef}
            type="button"
            onClick={() => openFrom(desktopToggleRef.current)}
            aria-expanded={open}
            aria-controls="menu-principal"
            className="px-6 py-3 bg-white rounded-full border border-black text-sm font-semibold hover:bg-black hover:text-white transition-colors duration-200"
          >
            Menu
          </button>
        </div>
        <button
          ref={toggleRef}
          type="button"
          onClick={() => openFrom(toggleRef.current)}
          aria-expanded={open}
          aria-controls="menu-principal"
          aria-label={open ? 'Fermer le menu' : 'Ouvrir le menu'}
          className="md:hidden w-11 h-11 flex items-center justify-center relative z-[60]"
        >
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              aria-hidden="true"
              className={`absolute h-0.5 w-6 bg-black rounded-full transition-all duration-300 ease-[cubic-bezier(0.76,0,0.24,1)] ${
                i === 0 ? (open ? 'rotate-45 translate-y-0' : '-translate-y-2') : i === 1 ? (open ? 'opacity-0 scale-x-0' : 'opacity-100 scale-x-100') : open ? '-rotate-45 translate-y-0' : 'translate-y-2'
              }`}
            />
          ))}
        </button>
      </header>

      <div className={`fixed inset-0 z-[55] ${open ? 'pointer-events-auto' : 'pointer-events-none'}`} aria-hidden={!open}>
        <div
          className={`absolute inset-0 bg-black/20 backdrop-blur-sm transition-opacity duration-500 ${open ? 'opacity-100' : 'opacity-0'}`}
          onClick={close}
        />
        <div
          ref={panelRef}
          id="menu-principal"
          role="dialog"
          aria-modal="true"
          aria-label="Menu principal"
          inert={!open}
          className={`absolute top-0 right-0 h-full w-[85%] max-w-sm bg-white shadow-2xl transition-transform duration-500 ease-[cubic-bezier(0.76,0,0.24,1)] ${open ? 'translate-x-0' : 'translate-x-full'}`}
        >
          <button
            type="button"
            onClick={close}
            className="absolute top-4 right-5 px-5 py-2.5 rounded-full border border-black text-sm font-semibold hover:bg-black hover:text-white transition-colors"
          >
            Fermer le menu
          </button>
          <nav aria-label="Navigation principale" className="flex flex-col justify-center h-full px-8 gap-1">
            {NAV_LINKS.map((l, i) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                style={linkDelay(i)}
                className={`text-3xl md:text-4xl font-bold text-black hover:text-neutral-500 py-1 transition-all duration-500 ease-[cubic-bezier(0.76,0,0.24,1)] ${open ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'}`}
              >
                {l.label}
              </a>
            ))}
            <div
              style={{ transitionDelay: open ? '450ms' : '0ms' }}
              className={`mt-8 pt-8 border-t border-neutral-200 transition-all duration-500 ${open ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'}`}
            >
              <p className="text-sm font-semibold text-black mb-4">
                Du lundi au vendredi · {COMPANY.phoneDisplay}
              </p>
              <a
                href={COMPANY.phoneHref}
                className="block text-center w-full px-6 py-4 bg-black rounded-full text-white text-sm font-semibold hover:bg-neutral-800 transition-colors duration-200"
              >
                Appeler le {COMPANY.phoneDisplay}
              </a>
            </div>
          </nav>
        </div>
      </div>
    </>
  )
}

/* ============================================================================
   PAGE D'ACCUEIL
   ========================================================================== */
function Hero() {
  const isMobile = useIsMobile()
  const sectionRef = useRef<HTMLElement | null>(null)
  const cardsRef = useRef<(HTMLElement | null)[]>([])
  const positions = useMaskPositions(sectionRef, cardsRef)
  const imageWidth = useImageWidth(HERO_IMAGE, positions[0]?.sh ?? 0)
  const reveal = useStaggeredReveal(4)
  const focalX = isMobile ? 0.7 : 0.8
  const setCard = (i: number) => (el: HTMLElement | null) => {
    cardsRef.current[i] = el
  }

  return (
    <section
      id="accueil"
      aria-labelledby="titre-accueil"
      ref={mergeRefs(sectionRef, reveal.containerRef)}
      className="h-[100svh] min-h-[640px] w-full overflow-hidden flex flex-col pt-20 md:pt-24 px-3 md:px-5 pb-1.5 md:pb-2 gap-1.5 md:gap-2 scroll-mt-0"
    >
      <ul className="contents" aria-label="Nos domaines d’intervention">
        {featureBars.map((label, i) => (
          <li key={label} className="contents">
            <MaskedCard
              bgImage={HERO_IMAGE}
              position={positions[i]}
              imageWidth={imageWidth}
              focalX={focalX}
              cardRef={setCard(i)}
              style={reveal.getAnimStyle(i)}
              className="w-full h-14 md:h-20 shrink-0 rounded-xl md:rounded-2xl overflow-hidden relative"
            >
              <span className="absolute inset-0 bg-white/80" aria-hidden="true" />
              <span className="relative z-10 flex items-center justify-center h-full text-black text-lg md:text-3xl font-bold text-center">
                {label}
              </span>
            </MaskedCard>
          </li>
        ))}
      </ul>

      <MaskedCard
        bgImage={HERO_IMAGE}
        position={positions[3]}
        imageWidth={imageWidth}
        focalX={focalX}
        cardRef={setCard(3)}
        style={reveal.getAnimStyle(3)}
        className="w-full flex-1 min-h-0 rounded-xl md:rounded-2xl overflow-hidden relative"
      >
        <span role="img" aria-label="Camionnette Desrues aux couleurs de l’entreprise, garée devant les locaux" className="absolute inset-0" />
        <p className="absolute top-3 left-3 md:top-6 md:left-6 z-10 max-w-[230px] md:max-w-[320px] bg-white/90 rounded-lg px-3 py-2 text-black text-xs md:text-sm font-semibold leading-4 md:leading-5">
          Installation et rénovation de vos équipements de plomberie et de chauffage, à Saint-Malo et alentours.
        </p>
        <div className="absolute bottom-3 left-3 right-3 md:bottom-6 md:left-4 md:right-auto z-10 bg-white/90 rounded-xl md:rounded-2xl px-3 pt-2 pb-3 md:px-5 md:pt-4 md:pb-5">
          <span className="block text-black text-xs md:text-sm font-semibold mb-1 md:mb-2">
            Plombier chauffagiste à Saint-Malo · depuis 1956
          </span>
          <h1 id="titre-accueil" className="text-black text-[clamp(2.6rem,9vw,8.5rem)] font-bold leading-[0.85] tracking-tight">
            Plomberie
            <br />
            Chauffage
            <span className="sr-only"> et énergies renouvelables à Saint-Malo – Desrues</span>
          </h1>
        </div>
        <a
          href={COMPANY.phoneHref}
          className="hidden md:inline-flex absolute bottom-8 right-8 z-10 px-8 py-5 bg-black text-white rounded-full text-xl font-bold hover:scale-105 transition-transform"
        >
          Appeler le {COMPANY.phoneDisplay}
        </a>
      </MaskedCard>
      <a
        href={COMPANY.phoneHref}
        className="md:hidden shrink-0 text-center px-5 py-3.5 bg-black text-white rounded-full text-base font-bold"
      >
        Appeler le {COMPANY.phoneDisplay}
      </a>
    </section>
  )
}

function Metiers() {
  const isMobile = useIsMobile()
  const sectionRef = useRef<HTMLElement | null>(null)
  const cardsRef = useRef<(HTMLElement | null)[]>([])
  const positions = useMaskPositions(sectionRef, cardsRef)
  const imageWidth = useImageWidth(MOTIF_IMAGE, positions[0]?.sh ?? 0)
  const reveal = useStaggeredReveal(4)
  const focalX = isMobile ? 0.65 : 0.8
  const setCard = (i: number) => (el: HTMLElement | null) => {
    cardsRef.current[i] = el
  }

  return (
    <section
      id="metiers"
      aria-labelledby="titre-metiers"
      ref={mergeRefs(sectionRef, reveal.containerRef)}
      className="on-dark min-h-screen md:h-screen md:min-h-[680px] w-full overflow-hidden flex flex-col pt-1.5 md:pt-2 px-3 md:px-5 pb-1.5 md:pb-2 gap-1.5 md:gap-2 scroll-mt-20"
    >
      <div className="flex-1 min-h-0 grid grid-cols-1 md:grid-cols-2 grid-rows-[auto_auto_auto_auto] md:grid-rows-[1fr_1fr_0.8fr] gap-1.5 md:gap-2">
        <MaskedCard
          bgImage={MOTIF_IMAGE}
          position={positions[0]}
          imageWidth={imageWidth}
          focalX={focalX}
          cardRef={setCard(0)}
          style={reveal.getAnimStyle(0)}
          className="rounded-xl md:rounded-2xl overflow-hidden relative min-h-[160px] md:min-h-0"
        >
          <h2 id="titre-metiers" className="absolute top-4 left-5 md:top-6 md:left-7 text-white text-2xl md:text-3xl font-bold z-10">
            Nos métiers
          </h2>
          <p className="absolute bottom-4 left-5 md:bottom-6 md:left-7 text-white text-xs md:text-sm font-semibold z-10">
            Construction neuve, extension et rénovation
          </p>
        </MaskedCard>

        <MaskedCard
          bgImage={MOTIF_IMAGE}
          position={positions[1]}
          imageWidth={imageWidth}
          focalX={focalX}
          cardRef={setCard(1)}
          style={reveal.getAnimStyle(1)}
          className="md:row-span-2 rounded-xl md:rounded-2xl overflow-hidden relative min-h-[220px] md:min-h-0"
        >
          <p className="absolute bottom-20 left-4 right-4 md:bottom-24 md:left-6 md:right-auto md:max-w-[340px] z-10 bg-[#083F23]/90 rounded-lg px-3 py-2 text-white text-xs md:text-sm font-semibold leading-4 md:leading-5">
            Un projet de salle de bain, de chaudière ou de pompe à chaleur ?
            <br />
            Appelez-nous pour en parler et obtenir un devis détaillé.
          </p>
          <a
            href={COMPANY.phoneHref}
            className="absolute bottom-4 right-4 md:bottom-6 md:right-6 px-5 py-3 md:px-8 md:py-5 bg-white rounded-full text-black text-base md:text-xl font-bold z-10 hover:scale-105 transition-transform"
          >
            Appeler le {COMPANY.phoneDisplay}
          </a>
        </MaskedCard>

        <MaskedCard
          bgImage={MOTIF_IMAGE}
          position={positions[2]}
          imageWidth={imageWidth}
          focalX={focalX}
          cardRef={setCard(2)}
          style={reveal.getAnimStyle(2)}
          className="rounded-xl md:rounded-2xl overflow-hidden relative min-h-[160px] md:min-h-0"
        >
          <p className="absolute top-4 left-5 md:top-6 md:left-7 text-white text-[clamp(2.6rem,6vw,5.5rem)] font-bold leading-[0.9] z-10">
            Neuf &amp;
            <br />
            rénovation
          </p>
        </MaskedCard>

        <MaskedCard
          bgImage={MOTIF_IMAGE}
          position={positions[3]}
          imageWidth={imageWidth}
          focalX={focalX}
          cardRef={setCard(3)}
          style={reveal.getAnimStyle(3)}
          className="col-span-1 md:col-span-2 rounded-xl md:rounded-2xl overflow-hidden relative min-h-[260px] md:min-h-0"
        >
          <ul className="absolute inset-0 z-10 flex flex-wrap md:flex-nowrap gap-1.5 md:gap-2 p-2 md:p-3" aria-label="Nos principales prestations">
            {services.map((svc) => (
              <li
                key={svc.name}
                className={`flex-1 min-w-[calc(50%-4px)] md:min-w-0 rounded-xl md:rounded-2xl p-3 md:p-5 flex flex-col justify-between ${
                  svc.active ? 'bg-white/95 backdrop-blur-md' : 'bg-black/60 backdrop-blur-xl'
                }`}
              >
                <h3 className={`text-lg md:text-3xl lg:text-4xl font-bold leading-[1.05] whitespace-pre-line hyphens-auto ${svc.active ? 'text-black' : 'text-white'}`}>
                  {svc.name}
                </h3>
                {svc.num && (
                  <span
                    aria-hidden="true"
                    className={`self-end w-8 h-8 md:w-12 md:h-12 rounded-full border flex items-center justify-center text-xs md:text-sm font-semibold ${svc.active ? 'border-black text-black' : 'border-white text-white'}`}
                  >
                    {svc.num}
                  </span>
                )}
              </li>
            ))}
          </ul>
        </MaskedCard>
      </div>
    </section>
  )
}

function Renouvelables() {
  const reveal = useStaggeredReveal(4)
  return (
    <section
      id="renouvelables"
      aria-labelledby="titre-renouvelables"
      ref={reveal.containerRef}
      className="min-h-screen md:h-screen md:min-h-[700px] w-full overflow-hidden flex flex-col pt-1.5 md:pt-2 px-3 md:px-5 pb-1.5 md:pb-2 gap-1.5 md:gap-2 scroll-mt-20"
    >
      <div className="flex-1 min-h-0 grid grid-cols-1 md:grid-cols-2 gap-1.5 md:gap-2">
        <div className="flex flex-col gap-1.5 md:gap-2 min-h-0">
          <div style={reveal.getAnimStyle(0)} className="rounded-xl md:rounded-2xl bg-stone-50 p-5 md:p-7 flex flex-col justify-between gap-6 flex-[1.2] min-h-[180px] md:min-h-0">
            <h2 id="titre-renouvelables" className="text-[clamp(2.6rem,6vw,6rem)] font-bold leading-[0.95] text-black hyphens-auto">
              Énergies
              <br />
              renouvelables
            </h2>
            <p className="text-xs md:text-sm font-semibold text-black">
              Entreprise qualifiée RGE – Qualibat · certificat n° <Todo>numéro et date de validité du certificat RGE</Todo>
            </p>
          </div>

          <div style={reveal.getAnimStyle(1)} className="flex gap-1.5 md:gap-2 flex-1 min-h-[160px] md:min-h-0">
            <div className="flex-1 rounded-xl md:rounded-2xl overflow-hidden bg-white border border-stone-200 flex items-center">
              <img src={SIGN_IMAGE} alt="Enseigne Desrues : plomberie, chauffage, énergies renouvelables, depuis 1956" className="w-full h-full object-contain" />
            </div>
            <a
              href="https://france-renov.gouv.fr/annuaires-professionnels/artisan-rge-architecte"
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 rounded-xl md:rounded-2xl bg-[#F5C400] text-black p-4 md:p-6 flex flex-col justify-between group"
            >
              <span className="text-xs md:text-sm font-semibold">Annuaire officiel France Rénov’</span>
              <span className="text-lg md:text-3xl font-bold leading-[1.05]">
                Vérifier notre qualification RGE
                <NewTabHint />
              </span>
              <span className="self-end w-9 h-9 md:w-12 md:h-12 rounded-full border border-black flex items-center justify-center group-hover:bg-black group-hover:text-[#F5C400] transition-colors">
                <ArrowIcon />
              </span>
            </a>
          </div>

          <div style={reveal.getAnimStyle(2)} className="rounded-xl md:rounded-2xl bg-zinc-200 p-5 md:p-7 flex flex-col sm:flex-row sm:items-end justify-between gap-4 flex-[0.8] min-h-[160px] md:min-h-0">
            <div>
              <p className="text-xs md:text-sm font-semibold text-black mb-2 md:mb-3">Votre projet</p>
              <h3 className="text-xl md:text-3xl font-bold text-black leading-6 md:leading-8">
                Demande
                <br />
                de devis
              </h3>
            </div>
            <a href="#contact" className="self-start sm:self-auto px-5 py-3 md:px-8 md:py-5 bg-white rounded-full text-black text-base md:text-xl font-bold hover:scale-105 transition-transform">
              Demander un devis
            </a>
          </div>
        </div>

        <div style={reveal.getAnimStyle(3)} className="on-dark rounded-xl md:rounded-2xl overflow-hidden relative min-h-[420px] md:min-h-0">
          <img src={MOTIF_IMAGE} alt="" className="absolute inset-0 w-full h-full object-cover object-[75%_50%]" />
          <div className="absolute top-5 left-5 right-5 md:top-7 md:left-7 max-w-md">
            <p className="text-white text-sm md:text-base font-semibold leading-5 md:leading-6 bg-[#083F23]/90 rounded-lg px-3 py-2">
              Pompe à chaleur, chaudière à condensation, chauffe-eau thermodynamique, radiateurs électriques et régulation : domaines couverts par notre qualification RGE.
            </p>
          </div>
          <div className="absolute bottom-3 left-3 right-3 md:bottom-5 md:left-5 md:right-5 flex gap-1.5 md:gap-2">
            <a
              href="https://france-renov.gouv.fr/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 bg-white rounded-xl md:rounded-2xl p-3 md:p-5 flex flex-col justify-between h-40 md:h-52 text-black group"
            >
              <span className="text-base md:text-2xl font-bold leading-5 md:leading-7">
                Aides à la rénovation : le site officiel France Rénov’
                <NewTabHint />
              </span>
              <span className="self-end w-9 h-9 md:w-12 md:h-12 rounded-full border border-black flex items-center justify-center group-hover:bg-black group-hover:text-white transition-colors">
                <ArrowIcon />
              </span>
            </a>
            <a
              href="#tarifs"
              className="flex-1 bg-black/60 backdrop-blur-xl rounded-xl md:rounded-2xl p-3 md:p-5 flex flex-col justify-between h-40 md:h-52 text-white group"
            >
              <span className="text-base md:text-2xl font-bold leading-5 md:leading-7">
                Nos tarifs
                <br />
                et devis
              </span>
              <span className="self-end w-9 h-9 md:w-12 md:h-12 rounded-full border border-white flex items-center justify-center group-hover:bg-white group-hover:text-black transition-colors">
                <ArrowIcon className="text-current" />
              </span>
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

function Tarifs() {
  const reveal = useStaggeredReveal(2)
  const rows: { label: string; value: ReactNode }[] = [
    { label: 'Taux horaire de main-d’œuvre (TTC)', value: <Todo>taux horaire TTC</Todo> },
    { label: 'Frais de déplacement (TTC)', value: <Todo>montant ou « aucun »</Todo> },
    { label: 'Devis', value: <Todo>« gratuit » ou coût TTC du devis</Todo> },
    { label: 'Prestations forfaitaires (TTC)', value: <Todo>liste des forfaits et prix TTC, ou « aucun forfait »</Todo> },
  ]
  return (
    <section
      id="tarifs"
      aria-labelledby="titre-tarifs"
      ref={reveal.containerRef}
      className="w-full px-3 md:px-5 pt-1.5 md:pt-2 pb-1.5 md:pb-2 grid grid-cols-1 md:grid-cols-[1fr_2fr] gap-1.5 md:gap-2 scroll-mt-20"
    >
      <div style={reveal.getAnimStyle(0)} className="rounded-xl md:rounded-2xl bg-black text-white p-5 md:p-7 flex flex-col justify-between gap-8 on-dark">
        <h2 id="titre-tarifs" className="text-[clamp(2.6rem,5vw,5rem)] font-bold leading-[0.95]">Tarifs</h2>
        <p className="text-xs md:text-sm font-semibold leading-5">
          Un devis détaillé vous est remis avant toute intervention de dépannage, de réparation ou d’entretien. Les travaux d’installation sont chiffrés sur devis.
        </p>
      </div>
      <div style={reveal.getAnimStyle(1)} className="rounded-xl md:rounded-2xl bg-stone-50 p-5 md:p-7">
        <dl className="divide-y divide-stone-300">
          {rows.map((r) => (
            <div key={r.label} className="py-4 flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-1 sm:gap-6">
              <dt className="text-sm md:text-base font-semibold text-black">{r.label}</dt>
              <dd className="text-sm md:text-base text-black sm:text-right">{r.value}</dd>
            </div>
          ))}
        </dl>
        <p className="mt-4 text-xs text-neutral-700 leading-5">
          Barème publié conformément à l’arrêté du 24 janvier 2017 relatif à la publicité des prix des prestations de dépannage, de réparation et d’entretien dans le secteur du bâtiment et de l’équipement de la maison.{' '}
          <a href="#/conditions" className="underline underline-offset-2 font-semibold">Devis, rétractation et remboursement</a>
        </p>
      </div>
    </section>
  )
}

const inputCls =
  'w-full rounded-xl border border-neutral-500 bg-white px-4 py-3 text-base text-black placeholder:text-neutral-600 focus:outline-none focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-[#0B5D33] aria-[invalid=true]:border-red-700'

function ContactForm() {
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [sent, setSent] = useState(false)
  const formRef = useRef<HTMLFormElement>(null)
  const summaryRef = useRef<HTMLDivElement>(null)

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const fd = new FormData(e.currentTarget)
    const v = (k: string) => String(fd.get(k) ?? '').trim()
    const errs: Record<string, string> = {}
    if (!v('nom')) errs.nom = 'Indiquez votre nom.'
    const tel = v('telephone')
    const mail = v('email')
    if (!tel && !mail) errs.telephone = 'Indiquez un numéro de téléphone ou une adresse e-mail pour que nous puissions vous répondre.'
    if (tel && !/^[+0-9 ().-]{10,20}$/.test(tel)) errs.telephone = 'Numéro de téléphone invalide (exemple : 06 12 34 56 78).'
    if (mail && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(mail)) errs.email = 'Adresse e-mail invalide (exemple : nom@exemple.fr).'
    if (v('message').length < 10) errs.message = 'Décrivez votre demande en quelques mots (10 caractères minimum).'
    if (v('message').length > 3000) errs.message = 'Votre message est trop long (3 000 caractères maximum).'
    setErrors(errs)
    if (Object.keys(errs).length) {
      setSent(false)
      requestAnimationFrame(() => summaryRef.current?.focus())
      return
    }
    const body = [
      `Nom : ${v('nom')}`,
      tel && `Téléphone : ${tel}`,
      mail && `E-mail : ${mail}`,
      v('commune') && `Commune des travaux : ${v('commune')}`,
      `Objet : ${v('objet')}`,
      '',
      v('message'),
    ]
      .filter((l): l is string => typeof l === 'string')
      .join('\n')
    const href = `mailto:${COMPANY.email}?subject=${encodeURIComponent(`Demande via le site : ${v('objet')}`)}&body=${encodeURIComponent(body)}`
    window.location.href = href
    setSent(true)
  }

  const field = (name: string) => ({
    id: `f-${name}`,
    name,
    'aria-invalid': errors[name] ? true : undefined,
    'aria-describedby': errors[name] ? `err-${name}` : undefined,
  })
  const Err = ({ name }: { name: string }) =>
    errors[name] ? (
      <p id={`err-${name}`} className="mt-1 text-sm font-semibold text-red-700">
        {errors[name]}
      </p>
    ) : null

  return (
    <form ref={formRef} noValidate onSubmit={onSubmit} className="flex flex-col gap-4" aria-describedby="form-info">
      <p id="form-info" className="text-sm text-black leading-5">
        Ce formulaire n’envoie rien depuis le site : il prépare un e-mail dans votre messagerie, que vous relisez puis envoyez vous-même à {COMPANY.email}. Les champs marqués d’un astérisque (*) sont obligatoires.
      </p>
      {Object.keys(errors).length > 0 && (
        <div ref={summaryRef} tabIndex={-1} role="alert" className="rounded-xl border-2 border-red-700 bg-red-50 p-4 text-sm text-red-800">
          <p className="font-bold">Le formulaire contient {Object.keys(errors).length} erreur(s) :</p>
          <ul className="list-disc pl-5 mt-1">
            {Object.entries(errors).map(([k, m]) => (
              <li key={k}>
                <a href={`#f-${k}`} className="underline" onClick={(e) => { e.preventDefault(); document.getElementById(`f-${k}`)?.focus() }}>
                  {m}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}
      <div>
        <label htmlFor="f-nom" className="block text-sm font-semibold mb-1">Nom *</label>
        <input {...field('nom')} type="text" autoComplete="name" required maxLength={100} className={inputCls} />
        <Err name="nom" />
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label htmlFor="f-telephone" className="block text-sm font-semibold mb-1">Téléphone (ou e-mail) *</label>
          <input {...field('telephone')} type="tel" autoComplete="tel" maxLength={20} className={inputCls} />
          <Err name="telephone" />
        </div>
        <div>
          <label htmlFor="f-email" className="block text-sm font-semibold mb-1">E-mail (ou téléphone) *</label>
          <input {...field('email')} type="email" autoComplete="email" maxLength={120} className={inputCls} />
          <Err name="email" />
        </div>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label htmlFor="f-commune" className="block text-sm font-semibold mb-1">Commune des travaux</label>
          <input {...field('commune')} type="text" autoComplete="address-level2" maxLength={80} className={inputCls} />
        </div>
        <div>
          <label htmlFor="f-objet" className="block text-sm font-semibold mb-1">Objet de la demande *</label>
          <select {...field('objet')} className={inputCls} defaultValue="Demande de devis">
            <option>Demande de devis</option>
            <option>Plomberie / salle de bain</option>
            <option>Chauffage / chaudière</option>
            <option>Pompe à chaleur / énergies renouvelables</option>
            <option>Autre demande</option>
          </select>
        </div>
      </div>
      <div>
        <label htmlFor="f-message" className="block text-sm font-semibold mb-1">Votre demande *</label>
        <textarea {...field('message')} rows={5} required maxLength={3000} className={inputCls} />
        <Err name="message" />
      </div>
      <p className="text-xs text-neutral-700 leading-5">
        Ne communiquez que les informations utiles à votre demande. Vos données servent uniquement à vous répondre et à établir un devis.{' '}
        <a href="#/confidentialite" className="underline font-semibold">Politique de confidentialité</a>
      </p>
      <button type="submit" className="self-start px-6 py-4 md:px-8 md:py-5 bg-black rounded-full text-white text-base md:text-lg font-bold hover:scale-105 transition-transform">
        Préparer l’e-mail dans ma messagerie
      </button>
      <p role="status" className="text-sm font-semibold text-[#0B5D33]">
        {sent ? `Votre messagerie devrait s’ouvrir. Si rien ne se passe, écrivez-nous directement à ${COMPANY.email} ou appelez le ${COMPANY.phoneDisplay}.` : ''}
      </p>
    </form>
  )
}

function Contact() {
  const reveal = useStaggeredReveal(2)
  return (
    <section
      id="contact"
      aria-labelledby="titre-contact"
      ref={reveal.containerRef}
      className="w-full px-3 md:px-5 pt-1.5 md:pt-2 pb-1.5 md:pb-2 grid grid-cols-1 md:grid-cols-2 gap-1.5 md:gap-2 scroll-mt-20"
    >
      <div style={reveal.getAnimStyle(0)} className="on-dark rounded-xl md:rounded-2xl bg-[#0B5D33] text-white p-5 md:p-7 flex flex-col gap-8">
        <h2 id="titre-contact" className="text-[clamp(2.6rem,5vw,5rem)] font-bold leading-[0.95]">Contact</h2>
        <address className="not-italic text-base md:text-lg leading-7">
          <strong className="block">{COMPANY.brand}</strong>
          {COMPANY.street}
          <br />
          {COMPANY.zip} {COMPANY.city}
        </address>
        <div>
          <h3 className="text-sm font-semibold mb-2">Horaires d’ouverture</h3>
          <dl className="text-sm md:text-base leading-7">
            {COMPANY.hours.map((h) => (
              <div key={h.days} className="flex flex-wrap gap-x-3">
                <dt className="font-semibold">{h.days} :</dt>
                <dd>{h.time}</dd>
              </div>
            ))}
          </dl>
        </div>
        <div className="flex flex-col sm:flex-row flex-wrap gap-2 mt-auto">
          <a href={COMPANY.phoneHref} className="text-center px-6 py-4 bg-white text-black rounded-full font-bold hover:scale-105 transition-transform">
            Appeler le {COMPANY.phoneDisplay}
          </a>
          <a href={`mailto:${COMPANY.email}`} className="text-center px-6 py-4 border-2 border-white rounded-full font-bold hover:bg-white hover:text-black transition-colors">
            Écrire à {COMPANY.email}
          </a>
          <a href={MAPS_URL} target="_blank" rel="noopener noreferrer" className="text-center px-6 py-4 border-2 border-white rounded-full font-bold hover:bg-white hover:text-black transition-colors">
            Voir l’itinéraire sur Google Maps
            <NewTabHint />
          </a>
        </div>
      </div>
      <div style={reveal.getAnimStyle(1)} className="rounded-xl md:rounded-2xl bg-stone-50 p-5 md:p-7">
        <h3 className="text-2xl md:text-3xl font-bold mb-4">Écrivez-nous</h3>
        <ContactForm />
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="on-dark mx-3 md:mx-5 mb-3 md:mb-5 mt-0 rounded-xl md:rounded-2xl bg-black text-white p-5 md:p-7 grid gap-6 md:grid-cols-[1.2fr_1fr]">
      <div className="text-sm leading-6">
        <p className="font-bold text-base">{COMPANY.legalName}</p>
        <p>
          {COMPANY.street}, {COMPANY.zip} {COMPANY.city} · <a className="underline" href={COMPANY.phoneHref}>{COMPANY.phoneDisplay}</a> ·{' '}
          <a className="underline" href={`mailto:${COMPANY.email}`}>{COMPANY.email}</a>
        </p>
        <p>SIRET {COMPANY.siret} · {COMPANY.rcs} · TVA {COMPANY.vat}</p>
        <p className="mt-3 text-neutral-300">Ce site n’utilise ni cookie ni outil de mesure d’audience.</p>
      </div>
      <nav aria-label="Informations légales">
        <ul className="flex flex-col gap-2 text-sm font-semibold">
          {(Object.keys(LEGAL_PAGES) as LegalRoute[]).map((r) => (
            <li key={r}>
              <a href={r} className="underline underline-offset-4 hover:text-neutral-300">{LEGAL_PAGES[r]}</a>
            </li>
          ))}
        </ul>
        <p className="mt-4 text-xs text-neutral-300">© {new Date().getFullYear()} {COMPANY.brand}</p>
      </nav>
    </footer>
  )
}

/* ============================================================================
   PAGES LÉGALES
   ========================================================================== */
function LegalLayout({ title, updated, children }: { title: string; updated: string; children: ReactNode }) {
  const h1 = useRef<HTMLHeadingElement>(null)
  useEffect(() => {
    h1.current?.focus()
  }, [title])
  return (
    <div className="px-3 md:px-5 pt-24 md:pt-28 pb-2">
      <div className="rounded-xl md:rounded-2xl bg-stone-50 p-5 md:p-10 max-w-4xl mx-auto">
        <a href="#accueil" className="inline-block text-sm font-semibold underline underline-offset-4 mb-6">← Retour à l’accueil</a>
        <h1 ref={h1} tabIndex={-1} className="text-[clamp(2.2rem,5vw,4.5rem)] font-bold leading-[0.95] text-black mb-3 focus:outline-none">{title}</h1>
        <p className="text-sm text-neutral-700 mb-8">Dernière mise à jour : {updated}</p>
        <div className="legal text-[15px] md:text-base leading-7 text-black space-y-4 [&_h2]:text-xl [&_h2]:md:text-2xl [&_h2]:font-bold [&_h2]:mt-10 [&_h2]:mb-2 [&_h3]:font-bold [&_h3]:mt-6 [&_ul]:list-disc [&_ul]:pl-6 [&_a]:underline [&_a]:underline-offset-2 [&_a]:font-semibold">
          {children}
        </div>
      </div>
    </div>
  )
}

const UPDATED = '18 septembre 2026'

function Ext({ href, children }: { href: string; children: ReactNode }) {
  return (
    <a href={href} target="_blank" rel="noopener noreferrer">
      {children}
      <NewTabHint />
    </a>
  )
}

function MentionsLegales() {
  return (
    <LegalLayout title="Mentions légales" updated={UPDATED}>
      <p>Informations publiées en application de l’article 1-1 de la loi n° 2004-575 du 21 juin 2004 pour la confiance dans l’économie numérique (LCEN).</p>

      <h2>Éditeur du site</h2>
      <ul>
        <li>Dénomination sociale : {COMPANY.legalName} (nom commercial : {COMPANY.brand})</li>
        <li>Forme juridique : {COMPANY.legalForm}, au capital de {COMPANY.capital}</li>
        <li>Siège social : {COMPANY.street}, {COMPANY.zip} {COMPANY.city}</li>
        <li>Immatriculation : {COMPANY.rcs} · SIRET du siège : {COMPANY.siret}</li>
        <li>N° de TVA intracommunautaire : {COMPANY.vat}</li>
        <li>Code NAF / APE : {COMPANY.naf}</li>
        <li>Téléphone : <a href={COMPANY.phoneHref}>{COMPANY.phoneDisplay}</a> · E-mail : <a href={`mailto:${COMPANY.email}`}>{COMPANY.email}</a></li>
        <li>Directeur de la publication : {COMPANY.president}, Président</li>
      </ul>

      <h2>Hébergeur</h2>
      <ul>
        <li>Nom ou dénomination : <Todo>nom de l’hébergeur</Todo></li>
        <li>Adresse : <Todo>adresse postale de l’hébergeur</Todo></li>
        <li>Téléphone : <Todo>téléphone de l’hébergeur</Todo></li>
      </ul>

      <h2>Qualifications et assurance</h2>
      <ul>
        <li>Qualification RGE délivrée par Qualibat, certificat n° <Todo>numéro et date de validité</Todo>. Domaines : pompe à chaleur (chauffage), chaudière à condensation ou micro-cogénération gaz ou fioul, chauffe-eau thermodynamique, radiateurs électriques et régulation. Vérification possible sur l’<Ext href="https://france-renov.gouv.fr/annuaires-professionnels/artisan-rge-architecte">annuaire officiel France Rénov’</Ext>.</li>
        <li>Assurance responsabilité civile décennale : <Todo>nom et adresse de l’assureur, numéro de contrat, couverture géographique</Todo>. Ces informations figurent également sur nos devis et factures.</li>
      </ul>

      <h2>Médiation de la consommation</h2>
      <p>
        Conformément aux articles L. 612-1 et suivants du Code de la consommation, en cas de litige non résolu après une réclamation écrite adressée à l’entreprise, le client consommateur peut recourir gratuitement au médiateur de la consommation suivant : <Todo>nom, adresse postale et site internet du médiateur auquel l’entreprise adhère</Todo>.
      </p>

      <h2>Propriété intellectuelle</h2>
      <p>
        Les textes, photographies, logo et éléments graphiques de ce site sont la propriété de {COMPANY.legalName} ou utilisés avec l’autorisation de leurs auteurs. Toute reproduction sans autorisation écrite préalable est interdite. Police de caractères « Open Sauce One » utilisée sous licence SIL Open Font License 1.1.
      </p>
      <p>Conception et réalisation du site : <Todo>nom du créateur du site (facultatif, supprimer la ligne sinon)</Todo>.</p>

      <h2>Accessibilité</h2>
      <p>
        Ce site a été conçu pour être utilisable au clavier et avec les lecteurs d’écran (textes alternatifs, contrastes renforcés, formulaire étiqueté). Il n’a pas fait l’objet d’un audit de conformité RGAA. Si vous rencontrez une difficulté, signalez-la à <a href={`mailto:${COMPANY.email}`}>{COMPANY.email}</a> ou au <a href={COMPANY.phoneHref}>{COMPANY.phoneDisplay}</a> : nous vous apporterons l’information par un autre moyen.
      </p>

      <h2>Données personnelles et cookies</h2>
      <p>
        Voir la <a href="#/confidentialite">politique de confidentialité</a> et la <a href="#/cookies">politique de cookies</a>.
      </p>
    </LegalLayout>
  )
}

function Confidentialite() {
  return (
    <LegalLayout title="Politique de confidentialité" updated={UPDATED}>
      <p>
        Cette politique explique comment {COMPANY.legalName} traite les données personnelles, conformément au Règlement (UE) 2016/679 (RGPD) et à la loi n° 78-17 du 6 janvier 1978 modifiée (« Informatique et Libertés »).
      </p>

      <h2>Responsable du traitement</h2>
      <p>
        {COMPANY.legalName}, {COMPANY.street}, {COMPANY.zip} {COMPANY.city} – <a href={`mailto:${COMPANY.email}`}>{COMPANY.email}</a> – <a href={COMPANY.phoneHref}>{COMPANY.phoneDisplay}</a>.
      </p>

      <h2>Ce que le site collecte</h2>
      <p>
        <strong>Le site lui-même ne collecte et n’enregistre aucune donnée vous concernant.</strong> Il ne dépose aucun cookie, n’utilise aucun outil de mesure d’audience, aucun pixel publicitaire, aucune carte ou vidéo intégrée, et ne charge aucune ressource depuis un serveur tiers (polices et images sont hébergées avec le site).
      </p>
      <p>
        Le formulaire de contact ne transmet rien au site : il prépare un e-mail dans votre propre logiciel de messagerie. Les données ne nous parviennent que si vous envoyez cet e-mail, ou si vous nous appelez.
      </p>
      <p>
        Comme pour tout site web, l’hébergeur enregistre techniquement des journaux de connexion (adresse IP, date, page demandée, navigateur) nécessaires à la sécurité et au fonctionnement du service. Durée de conservation : <Todo>durée de conservation des journaux chez l’hébergeur</Todo>.
      </p>

      <h2>Données que vous nous envoyez (e-mail, téléphone)</h2>
      <ul>
        <li><strong>Données :</strong> nom, coordonnées (téléphone et/ou e-mail), commune et description des travaux, et toute information que vous choisissez de nous communiquer.</li>
        <li><strong>Finalités :</strong> répondre à votre demande, établir un devis, réaliser et facturer les travaux.</li>
        <li><strong>Bases légales :</strong> mesures précontractuelles prises à votre demande et exécution du contrat (article 6.1.b du RGPD) ; respect de nos obligations légales, notamment comptables et fiscales (article 6.1.c).</li>
        <li><strong>Destinataires :</strong> le personnel de l’entreprise habilité à traiter votre demande ; nos prestataires techniques (messagerie électronique : <Todo>nom du fournisseur de messagerie</Todo>) ; le cas échéant notre expert-comptable. Vos données ne sont ni vendues ni cédées, et ne sont pas utilisées à des fins de prospection commerciale.</li>
        <li><strong>Durées de conservation :</strong> demandes sans suite : 3 ans à compter du dernier contact ; clients : durée de la relation contractuelle puis durée de prescription applicable (jusqu’à 10 ans pour la garantie décennale) ; pièces comptables et factures : 10 ans (article L. 123-22 du Code de commerce).</li>
        <li><strong>Transferts hors Union européenne :</strong> <Todo>« aucun » ou préciser selon l’hébergeur et le fournisseur de messagerie</Todo>.</li>
      </ul>

      <h2>Vos droits</h2>
      <p>
        Vous disposez d’un droit d’accès, de rectification, d’effacement, de limitation, d’opposition et de portabilité de vos données, ainsi que du droit de définir des directives relatives à leur sort après votre décès. Pour les exercer, écrivez à <a href={`mailto:${COMPANY.email}`}>{COMPANY.email}</a> ou à l’adresse postale ci-dessus. Nous répondons dans un délai d’un mois.
      </p>
      <p>
        Si vous estimez que vos droits ne sont pas respectés, vous pouvez adresser une réclamation à la CNIL : <Ext href="https://www.cnil.fr/fr/plaintes">www.cnil.fr/fr/plaintes</Ext>.
      </p>

      <h2>Sécurité</h2>
      <p>Le site est servi exclusivement en HTTPS. Il ne contient ni compte utilisateur, ni paiement en ligne, ni base de données.</p>
    </LegalLayout>
  )
}

function Cookies() {
  return (
    <LegalLayout title="Politique de cookies" updated={UPDATED}>
      <h2>Ce site ne dépose aucun cookie</h2>
      <p>
        Ce site ne dépose et ne lit aucun cookie ni autre traceur sur votre appareil (pas de mesure d’audience, pas de publicité, pas de réseau social, pas de carte ou de vidéo intégrée, pas de stockage local du navigateur).
      </p>
      <h2>Pourquoi aucun bandeau de consentement n’est affiché</h2>
      <p>
        L’article 82 de la loi « Informatique et Libertés » impose de recueillir votre consentement avant de déposer des traceurs non indispensables au fonctionnement du site. Comme ce site n’en utilise aucun, aucun consentement n’est à recueillir et aucun bandeau n’est affiché.
      </p>
      <h2>Liens vers d’autres sites</h2>
      <p>
        Certains liens (Google Maps pour l’itinéraire, France Rénov’, CNIL) ouvrent un site tiers dans un nouvel onglet. Ces sites appliquent leur propre politique de cookies, que nous vous invitons à consulter.
      </p>
      <h2>Évolution</h2>
      <p>
        Si un outil de mesure d’audience ou un contenu tiers était ajouté à l’avenir, cette page serait mise à jour et, lorsque la loi l’exige, votre consentement serait demandé au préalable, avec la possibilité de refuser aussi facilement que d’accepter.
      </p>
    </LegalLayout>
  )
}

function Conditions() {
  return (
    <LegalLayout title="Devis, rétractation et remboursement" updated={UPDATED}>
      <p>
        {COMPANY.legalName} ne vend rien en ligne : aucun paiement n’est effectué sur ce site. Cette page résume les règles applicables à nos devis et à nos travaux pour les clients particuliers (consommateurs). Les conditions complètes figurent sur chaque devis.
      </p>

      <h2>Devis</h2>
      <ul>
        <li>Un devis détaillé, écrit, vous est remis avant l’exécution de toute prestation de dépannage, de réparation ou d’entretien (arrêté du 24 janvier 2017), ainsi que pour les travaux d’installation.</li>
        <li>Il précise notamment le détail et le prix TTC des prestations et fournitures, les éventuels frais de déplacement, la durée de validité de l’offre et le caractère gratuit ou payant du devis.</li>
        <li>Nos tarifs de main-d’œuvre, de déplacement et de devis sont publiés dans la rubrique <a href="#tarifs">Tarifs</a>.</li>
      </ul>

      <h2>Droit de rétractation</h2>
      <p>
        Si le contrat est conclu <strong>à votre domicile</strong> (hors de nos locaux) ou <strong>à distance</strong> (par téléphone ou e-mail, sans présence physique simultanée), vous disposez d’un délai de <strong>14 jours</strong> à compter de la conclusion du contrat pour vous rétracter, sans avoir à motiver votre décision ni à supporter d’autres coûts que ceux prévus par la loi (articles L. 221-18 et suivants du Code de la consommation).
      </p>
      <p>
        Pour l’exercer, adressez-nous avant l’expiration du délai une déclaration dénuée d’ambiguïté (lettre à {COMPANY.street}, {COMPANY.zip} {COMPANY.city}, ou e-mail à <a href={`mailto:${COMPANY.email}`}>{COMPANY.email}</a>), ou le formulaire ci-dessous.
      </p>
      <p>
        Un contrat signé <strong>dans nos locaux</strong> n’ouvre pas de droit légal de rétractation.
      </p>

      <h3>Exceptions et cas particuliers</h3>
      <ul>
        <li>
          <strong>Travaux urgents :</strong> le droit de rétractation ne s’applique pas aux travaux d’entretien ou de réparation à réaliser en urgence à votre domicile et expressément sollicités par vous, dans la limite des pièces de rechange et travaux strictement nécessaires pour répondre à l’urgence (article L. 221-28, 8°).
        </li>
        <li>
          <strong>Début des travaux avant la fin du délai :</strong> si vous demandez expressément, par écrit, que les travaux commencent avant la fin du délai de 14 jours et que vous vous rétractez ensuite, vous devez payer un montant proportionnel à ce qui a été réalisé jusqu’à votre rétractation (article L. 221-25). Si la prestation a été entièrement exécutée avant la fin du délai, avec votre accord préalable exprès et votre renoncement exprès à votre droit de rétractation, ce droit ne peut plus être exercé (article L. 221-28, 1°).
        </li>
        <li>
          <strong>Paiement :</strong> pour un contrat conclu à votre domicile, aucun paiement ni acompte ne peut être exigé avant l’expiration d’un délai de 7 jours à compter de la conclusion du contrat, sauf dans les cas prévus par l’article L. 221-10 du Code de la consommation.
        </li>
      </ul>

      <h2>Remboursement</h2>
      <p>
        En cas de rétractation valable, nous vous remboursons la totalité des sommes versées au plus tard <strong>14 jours</strong> après avoir été informés de votre décision, en utilisant le même moyen de paiement que celui utilisé pour la transaction initiale, sauf accord exprès de votre part pour un autre moyen, et sans frais pour vous (article L. 221-24). Le cas échéant, le montant proportionnel aux travaux déjà réalisés à votre demande est déduit.
      </p>
      <p>
        En dehors du droit de rétractation, un acompte versé n’est remboursable que dans les conditions prévues au devis signé ou en cas d’inexécution de notre part.
      </p>

      <h2>Garanties légales sur les travaux</h2>
      <p>Selon la nature des travaux réalisés, s’appliquent notamment :</p>
      <ul>
        <li>la garantie de parfait achèvement : 1 an à compter de la réception des travaux (article 1792-6 du Code civil) ;</li>
        <li>la garantie biennale de bon fonctionnement des éléments d’équipement dissociables : 2 ans (article 1792-3 du Code civil) ;</li>
        <li>la garantie décennale : 10 ans pour les dommages compromettant la solidité de l’ouvrage ou le rendant impropre à sa destination (articles 1792 et 1792-4-1 du Code civil).</li>
      </ul>

      <h2>Réclamation et médiation</h2>
      <p>
        Pour toute réclamation, contactez-nous d’abord par écrit à <a href={`mailto:${COMPANY.email}`}>{COMPANY.email}</a> ou par courrier. À défaut de solution, vous pouvez saisir gratuitement le médiateur de la consommation : <Todo>nom, adresse et site internet du médiateur</Todo>.
      </p>

      <h2>Modèle de formulaire de rétractation</h2>
      <p className="text-sm">(Annexe à l’article R. 221-1 du Code de la consommation – à compléter et renvoyer uniquement si vous souhaitez vous rétracter du contrat.)</p>
      <div className="rounded-xl border border-stone-300 bg-white p-4 md:p-6 text-sm leading-7">
        <p>À l’attention de {COMPANY.legalName}, {COMPANY.street}, {COMPANY.zip} {COMPANY.city} – {COMPANY.email} :</p>
        <p>Je/Nous (*) vous notifie/notifions (*) par la présente ma/notre (*) rétractation du contrat portant sur la prestation de services ci-dessous :</p>
        <p>Commandé le (*) / reçu le (*) :</p>
        <p>Nom du (des) consommateur(s) :</p>
        <p>Adresse du (des) consommateur(s) :</p>
        <p>Signature du (des) consommateur(s) (uniquement en cas de notification du présent formulaire sur papier) :</p>
        <p>Date :</p>
        <p>(*) Rayez la mention inutile.</p>
      </div>
    </LegalLayout>
  )
}

/* ============================================================================
   ROUTAGE (par ancre #/…, compatible avec tout hébergement statique)
   ========================================================================== */
function useHashRoute() {
  const [hash, setHash] = useState(() => window.location.hash)
  useEffect(() => {
    const on = () => setHash(window.location.hash)
    window.addEventListener('hashchange', on)
    return () => window.removeEventListener('hashchange', on)
  }, [])
  return hash
}

export default function App() {
  const hash = useHashRoute()
  const legal = (hash in LEGAL_PAGES ? hash : null) as LegalRoute | null

  useEffect(() => {
    document.title = legal
      ? `${LEGAL_PAGES[legal]} – Desrues, Saint-Malo`
      : 'Desrues – Plomberie, chauffage, énergies renouvelables à Saint-Malo'
    if (legal) window.scrollTo(0, 0)
    else if (hash && !hash.startsWith('#/')) {
      requestAnimationFrame(() => document.getElementById(hash.slice(1))?.scrollIntoView())
    }
  }, [legal, hash])

  return (
    <div className="bg-white text-black">
      <a
        href="#contenu"
        onClick={(e) => {
          e.preventDefault()
          document.getElementById('contenu')?.focus()
        }}
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[200] focus:bg-black focus:text-white focus:px-4 focus:py-3 focus:rounded-full"
      >
        Aller au contenu
      </a>
      <Navbar />
      <main id="contenu" tabIndex={-1} className="focus:outline-none">
        {legal === '#/mentions-legales' && <MentionsLegales />}
        {legal === '#/confidentialite' && <Confidentialite />}
        {legal === '#/cookies' && <Cookies />}
        {legal === '#/conditions' && <Conditions />}
        {!legal && (
          <>
            <Hero />
            <Metiers />
            <Renouvelables />
            <Tarifs />
            <Contact />
          </>
        )}
      </main>
      <Footer />
    </div>
  )
}
