import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'
import { viteSingleFile } from 'vite-plugin-singlefile'

// `npm run build`         -> site de production (dossier dist/, à mettre en ligne)
// `npm run build:preview` -> un seul fichier HTML autonome, pour prévisualiser/envoyer une maquette
export default defineConfig(({ mode }) => ({
  plugins: [
    react(),
    ...(mode === 'preview'
      ? [
          viteSingleFile(),
          {
            name: 'csp-inline-preview',
            transformIndexHtml: (html: string) =>
              html.replace("script-src 'self'", "script-src 'self' 'unsafe-inline'"),
          },
        ]
      : []),
  ],
  build: mode === 'preview' ? { outDir: 'dist-preview', assetsInlineLimit: 100_000_000 } : {},
}))
